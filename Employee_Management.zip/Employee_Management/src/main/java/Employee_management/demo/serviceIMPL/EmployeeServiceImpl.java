
package Employee_management.demo.serviceIMPL;


import Employee_management.demo.model.Employee;
import Employee_management.demo.repository.EmployeeRepo;
import Employee_management.demo.service.EmployeeService;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceImpl implements EmployeeService{
@Autowired
   private EmployeeRepo employeeRepo;
    
    
    @Override
    public Employee addEmployee(Employee employeed) {
        
        
       Employee emp= employeeRepo.save(employeed);
       return emp;
    }

    @Override
    public String removeEmployee(int id) {
       employeeRepo.deleteById(id);
       return "delete data Successfully";
    }

    @Override
    public Optional<Employee> findEmpByid(int id) {
        Optional<Employee> emp=employeeRepo.findById(id);
        if(emp.isPresent()){
            return emp;
        }else{
             return null;
        }
        
    }

    @Override
    public List<Employee> getAllEmployee() {
       List<Employee> emp= employeeRepo.findAll();
       return emp;
    }

    @Override
    public String updateEmployee(int id) {
        Optional<Employee> emp=employeeRepo.findById(id);
        if(emp.isPresent()){
            Employee emps=new Employee();
            employeeRepo.save(emps);
            return "update succesfullt";
        }
        else{
            return"employee not found";
        }
    }

    
}
