
package Employee_management.demo.controller;

import Employee_management.demo.model.Employee;
import Employee_management.demo.repository.EmployeeRepo;
import Employee_management.demo.serviceIMPL.EmployeeServiceImpl;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class EmployeeController {
    
    @Autowired
    private EmployeeServiceImpl empservice;
    
    @PostMapping("/addEmp")
    public ResponseEntity<Employee> addEmployee(@RequestBody Employee employee){
       Employee emp=empservice.addEmployee(employee);
       
        return  new ResponseEntity<>(emp,HttpStatus.CREATED);
    }
    @DeleteMapping("/removeEmp/{id}")
    public ResponseEntity<String> removeEmployee(@PathVariable int id){
        empservice.removeEmployee(id);
        return new ResponseEntity<>("remove success",HttpStatus.ACCEPTED);
    }
    
    @GetMapping("/findEmp/{id}")
    public ResponseEntity<Optional<Employee>> findEmplyeeById(@PathVariable int id){
        Optional<Employee> emps=empservice.findEmpByid(id);
        
        return new ResponseEntity<>(emps,HttpStatus.ACCEPTED);
    }
    @GetMapping("/all")
    public ResponseEntity<List<Employee>> listOfEmployees(){
        List<Employee> Emp=empservice.getAllEmployee();
        return new ResponseEntity<>(Emp,HttpStatus.ACCEPTED);
    }
}
