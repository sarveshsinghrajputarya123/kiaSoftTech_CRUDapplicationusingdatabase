
package Employee_management.demo.service;

import Employee_management.demo.model.Employee;
import java.util.List;
import java.util.Optional;


public interface EmployeeService {
    
    
    public Employee addEmployee(Employee employeed);
    public String removeEmployee(int id);
    public Optional<Employee> findEmpByid(int id);
    public List<Employee> getAllEmployee();
    public String updateEmployee(int id);
}
